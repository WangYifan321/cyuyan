<template>
<h1>adminrehis</h1>
</template>

<script>
export default {
  name: "admin_register"
}
</script>

<style scoped>

</style>
