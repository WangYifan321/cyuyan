# campus-outsiders-management
Campus personnel in and out of the monitoring and management system
